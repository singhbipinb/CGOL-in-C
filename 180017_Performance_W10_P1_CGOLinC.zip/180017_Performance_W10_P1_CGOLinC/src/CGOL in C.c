/*
 ============================================================================
 Name        : CGOL.c
 Author      : Bipin Singh
 Version     : 1.0
 Description   : This program is of the Conway's Game of Life
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {

	// I had taken array of 8 x 8

	int Arr[8][8];


/* Taking input of the Array
 *
 *
 */

	printf("Enter the Intial state \n"
			"0 for dead \n"
			"1 for alive \n");
	fflush(stdout);


	int i,j;
		for(i=0;i<8;i++){
printf("Enter the %d row",i+1);
fflush(stdout);

			for(j=0;j<8;j++){

				scanf("%d",&Arr[i][j]);

			}

		}



	for(i=0;i<8;i++){

		for(j=0;j<8;j++){

			printf("%d",Arr[i][j]);

		}
		printf("\n");
	}

const int a=8,b=8;
	void CGOL(int a,int b,int Arr[a][b]);

	CGOL(a,b, Arr);

	return 0;
}

/* Method to implement the rules of CGOL
 *
 */


void CGOL(int a, int b, int ar[a][b]){

	int ARR[8][8];

	int d,e;

	for(d=0;d<8;d++){

		for(e=0;e<8;e++){

ARR[d][e]=0;

		}

	}

/* Takes input of number of generation needed by the user
 *
 *
 */

printf("Enter number of generations you want \n");
fflush(stdout);
int states;
scanf("%d",&states);
int f;



for(f=1;f<=states;f++){

	int i,j;
	int alive=0;
		for(i=0;i<8;i++){

			for(j=0;j<8;j++){
alive=0;

/*Count the number of alive cells in neighborhood
 *
 *
 */

	if(ar[i-1][j-1]==1){		//checks the up left neighbor
		alive++;
	}

	if(ar[i-1][j]==1){		//checks the up neighbor
			alive++;
		}
	if(ar[i-1][j+1]==1){		//checks the up right neighbor
			alive++;
		}

	if(ar[i][j-1]==1){		//checks the left neighbor
			alive++;
		}

	if(ar[i][j+1]==1){		//checks the right neighbor
			alive++;
		}

	if(ar[i+1][j-1]==1){		//checks the bottom left neighbor
			alive++;
		}

	if(ar[i+1][j]==1){		//checks the bottom neighbor
			alive++;
		}

	if(ar[i+1][j+1]==1){		//checks the bottom right neighbor
			alive++;
		}



	// Each cell with one or no neighbors dies, as if by under-population

	if(alive<2){
		ARR[i][j]=0;
	}



	else if(alive==2){

	// Each cell with two neighbors survives

		if(ar[i][j]==1){

			ARR[i][j]=1;
		}

	// If the cell has two alive neighbors and it is dead then it will remain dead
		else{

		ARR[i][j]=0;
		}

	}

	// Each cell with three neighbors survives
	// Each cell with three neighbors becomes populated


	else if (alive==3){

		ARR[i][j]=1;
	}

	//Each cell with four or more neighbors dies, as if by overpopulation

	else if(alive>3){
		ARR[i][j]=0;

		}


	}

}

	// print the new array

	printf("%d stage \n",f);

	int k,l;
			for(k=0;k<8;k++){

					for(l=0;l<8;l++){

						printf("%d",ARR[k][l]);

					}
					printf("\n");
				}


	//gives the value of new array(state) to the previous array

		for(k=0;k<8;k++){
				for(l=0;l<8;l++){

					ar[k][l]=ARR[k][l];

					}

				}

	}

}

